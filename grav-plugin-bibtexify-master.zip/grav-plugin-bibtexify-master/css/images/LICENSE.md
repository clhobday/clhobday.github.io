# Icons

twitter, pdf, online, bibtex, close
by Keyamoon http://keyamoon.com 
Released under the CC BY 4.0 or GPL
Visit IcoMoon.io for more information

sprites based on Keyamoon icons created by martinec
Released under the CC BY 4.0 or GPL
