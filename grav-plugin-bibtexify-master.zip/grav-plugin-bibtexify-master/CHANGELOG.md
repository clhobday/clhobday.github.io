# v1.2.0
## 05/07/2021

1. [](#new)
    * Allow to customize authors style using CSS (feature-request #11)

# v1.1.1
## 04/24/2018

1. [](#improved)
    * Turn vertically year labels

# v1.1.0
## 02/17/2017

1. [](#new)
    * Allow to customize publication entries using CSS styles (feature-request #1)
    * Use icons to twitter, pdf, online and bibtex links

# v1.0.0
## 01/23/2017

1. [](#new)
    * ChangeLog started...
